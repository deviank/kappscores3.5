<aside role="complimentary">
    <?php dynamic_sidebar( 'primary-sidebar' );?>       
</aside>