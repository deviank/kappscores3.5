# kappscores-metaboxes
WordPress plugin that adds meta box fields to different post types
